#pragma once
#ifndef DREWDUINO_I2CRELAY_PCA95X5_H
#define DREWDUINO_I2CRELAY_PCA95X5_H

#include <Arduino.h>
#include <Wire.h>

/*
  Drewduino_I2CRelay_PCA95x5
  Header-only драйвер для I2C-реле модулей на PCA9555/PCA9535/TCA9535 (совместимые регистры 0x00..0x07).

  Особенности:
  - relaySet(index, 1/0) или relaySet(index, true/false)
  - allOn(), allOff(), toggle(), toggle(index)
  - setMask(mask), getMask()
  - чтение input портов: readInputsRaw()
  - Wire используется напрямую
  - activeLow=true по умолчанию (часто реле включается уровнем 0)

  Нумерация реле:
  - relayIndex1: 1..relayCount

  Примечание по перегрузкам:
  - relaySet(i, 1) может быть двусмысленным при наличии bool/uint8_t перегрузок.
    Поэтому сделаны перегрузки: (uint8_t,bool) и (uint8_t,int).
*/

class Drewduino_I2CRelay_PCA95x5 {
public:
  Drewduino_I2CRelay_PCA95x5() = default;

  // begin: проверка ACK + настройка направлений + выключение всех реле
  // relayCount: 1..16
  bool begin(uint8_t i2cAddress, uint8_t relayCount,
             TwoWire& wire = Wire, bool activeLow = true)
  {
    _wire = &wire;
    _addr = i2cAddress;
    _count = constrain(relayCount, (uint8_t)1, (uint8_t)16);
    _activeLow = activeLow;
    _usedMask = (_count == 16) ? 0xFFFFu : (uint16_t)((1u << _count) - 1u);

    if (!probe()) return false;

    // Polarity inversion = 0 (обычно не нужно)
    if (!writeReg16(REG_POLARITY_0, 0x0000)) return false;

    // Configuration: используемые биты -> output(0), остальные -> input(1)
    uint16_t cfg = 0xFFFFu;
    cfg &= ~_usedMask;
    if (!writeReg16(REG_CONFIG_0, cfg)) return false;

    // Выключить все логически
    setMask(0);
    return true;
  }

  // ===== Управление реле: ВАРИАНТ A =====
  // relaySet(index, 1/0) или relaySet(index, true/false)

  // 1) удобный bool
  bool relaySet(uint8_t relayIndex1, bool on) {
    if (!inRange(relayIndex1)) return false;
    return setBitLogical(relayIndex1, on);
  }

  // 2) удобный 0/1 (int решает неоднозначность с bool на многих компиляторах Arduino)
  bool relaySet(uint8_t relayIndex1, int onOff01) {
    if (!inRange(relayIndex1)) return false;
    return setBitLogical(relayIndex1, (onOff01 != 0));
  }

  // Прочитать состояние реле (возвращает 0/1)
  uint8_t relayGet(uint8_t relayIndex1) {
    if (!inRange(relayIndex1)) return 0;
    uint16_t logical = getMask(true);
    uint16_t bit = (uint16_t)(1u << (relayIndex1 - 1u));
    return (logical & bit) ? 1 : 0;
  }

  bool allOn()  { return setMask(_usedMask); }
  bool allOff() { return setMask(0); }

  // toggle одно реле (по чтению текущего состояния)
  bool toggle(uint8_t relayIndex1) {
    if (!inRange(relayIndex1)) return false;
    uint16_t logical = getMask(true);
    uint16_t bit = (uint16_t)(1u << (relayIndex1 - 1u));
    logical ^= bit;
    return setMask(logical);
  }

  // toggle все
  bool toggle() {
    uint16_t logical = getMask(true);
    logical ^= _usedMask;
    return setMask(logical);
  }

  // setMask: логическая маска (1=включено, 0=выключено)
  bool setMask(uint16_t logicalMask) {
    logicalMask &= _usedMask;

    // логика -> уровни в output latch
    uint16_t outUsed;
    if (_activeLow) outUsed = (uint16_t)(~logicalMask) & _usedMask; // ON=0
    else           outUsed = logicalMask & _usedMask;               // ON=1

    uint16_t newOut = (_out & (uint16_t)(~_usedMask)) | outUsed;
    _out = newOut;

    return writeReg16(REG_OUTPUT_0, _out);
  }

  // getMask: возвращает логическую маску (1=включено, 0=выключено)
  uint16_t getMask(bool forceReadFromChip = true) {
    if (forceReadFromChip) {
      uint16_t raw;
      if (readReg16(REG_OUTPUT_0, raw)) _out = raw;
    }

    uint16_t logical;
    if (_activeLow) logical = (uint16_t)(~_out) & _usedMask;
    else           logical = _out & _usedMask;

    return logical;
  }

  // Сырые входы (если нужен фидбек/использование как IO expander)
  bool readInputsRaw(uint16_t& inputs) { return readReg16(REG_INPUT_0, inputs); }

  uint8_t lastI2CError() const { return _lastErr; }

  bool setActiveLow(bool activeLow) {
    if (_activeLow == activeLow) return true;
    uint16_t logical = getMask(true);
    _activeLow = activeLow;
    return setMask(logical);
  }

private:
  // PCA95x5 register pointers
  static constexpr uint8_t REG_INPUT_0    = 0x00;
  static constexpr uint8_t REG_OUTPUT_0   = 0x02;
  static constexpr uint8_t REG_POLARITY_0 = 0x04;
  static constexpr uint8_t REG_CONFIG_0   = 0x06;

  TwoWire* _wire = &Wire;
  uint8_t  _addr = 0x20;
  uint8_t  _count = 8;
  bool     _activeLow = true;
  uint16_t _usedMask = 0x00FF;
  uint16_t _out = 0xFFFF;   // output latch cache
  uint8_t  _lastErr = 0;

  bool inRange(uint8_t relayIndex1) const {
    return (relayIndex1 >= 1u && relayIndex1 <= _count);
  }

  bool setBitLogical(uint8_t relayIndex1, bool on) {
    uint16_t logical = getMask(true);
    uint16_t bit = (uint16_t)(1u << (relayIndex1 - 1u));
    if (on) logical |= bit;
    else    logical &= ~bit;
    return setMask(logical);
  }

  bool probe() {
    _wire->beginTransmission(_addr);
    _lastErr = _wire->endTransmission();
    return (_lastErr == 0);
  }

  bool writeReg16(uint8_t reg, uint16_t value) {
    _wire->beginTransmission(_addr);
    _wire->write(reg);
    _wire->write((uint8_t)(value & 0xFF));        // port0
    _wire->write((uint8_t)((value >> 8) & 0xFF)); // port1
    _lastErr = _wire->endTransmission();
    return (_lastErr == 0);
  }

  bool readReg16(uint8_t reg, uint16_t& value) {
    _wire->beginTransmission(_addr);
    _wire->write(reg);
    _lastErr = _wire->endTransmission(false); // repeated start
    if (_lastErr != 0) return false;

    uint8_t n = _wire->requestFrom((int)_addr, (int)2);
    if (n != 2) return false;

    uint8_t lo = _wire->read();
    uint8_t hi = _wire->read();
    value = (uint16_t)lo | ((uint16_t)hi << 8);
    return true;
  }
};

#endif // DREWDUINO_I2CRELAY_PCA95X5_H
