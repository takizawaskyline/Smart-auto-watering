# Drewduino I2C Relay (PCA95x5 compatible)

Простая Arduino‑библиотека для управления 8/16‑канальными I2C‑модулями реле на **PCA9555 / PCA9535 / TCA9535** и совместимых
(семейство PCA95x5 с одинаковой картой регистров `0x00..0x07`).

Фокус — максимально простой API для реле:
- `relaySet(n, 1/0)` или `relaySet(n, true/false)`
- `allOn() / allOff()`
- `toggle(n)` или `toggle()` (все)
- `setMask(mask)` / `getMask()`
- чтение входов `readInputsRaw()` (по желанию)

> Большинство реле‑плат — **active‑low** (включение = уровень `0` на выходе).  
> Поэтому по умолчанию `activeLow=true`. Если у вашей платы наоборот — передайте `activeLow=false`.

## Установка

### Вариант 1: GitHub ZIP
1. **Code → Download ZIP**
2. Arduino IDE: **Sketch → Include Library → Add .ZIP Library...**

### Вариант 2: папка в `libraries/`
Скопируйте папку `Drewduino_I2CRelay_PCA95x5` в:
- Windows: `Documents/Arduino/libraries/`
- Linux: `~/Arduino/libraries/`
- macOS: `~/Documents/Arduino/libraries/`

## Быстрый старт

```cpp
#include <Wire.h>
#include <Drewduino_I2CRelay_PCA95x5.h>

Drewduino_I2CRelay_PCA95x5 relay;

void setup() {
  Wire.begin();
  relay.begin(0x20, 8, Wire, true); // addr, count, wire, activeLow
  relay.allOff();

  relay.relaySet(1, 1); // ON
  relay.relaySet(2, 0); // OFF
}
```

## Адрес I2C

Чаще всего `0x20..0x27` (A0..A2). Если не знаете адрес — используйте I2C‑сканер.

## Примеры

- **examples/Demo** — демонстрация управления реле.
- **examples/ReadStates** — чтение состояния реле + чтение raw input портов.

## Лицензия

MIT
